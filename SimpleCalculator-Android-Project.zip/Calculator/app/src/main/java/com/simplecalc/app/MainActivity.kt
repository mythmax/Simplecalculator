package com.simplecalc.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.simplecalc.app.databinding.ActivityMainBinding
import java.text.DecimalFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Текущее состояние
    private var currentNumber: String = "0"      // число, которое сейчас вводится
    private var storedValue: Double? = null       // сохранённый предыдущий операнд
    private var pendingOperator: String? = null    // ожидающая операция: +, -, ×, ÷
    private var expressionText: String = ""        // строка над результатом (для отображения)
    private var justCalculated = false              // true сразу после нажатия "="

    private val decimalFormat = DecimalFormat("#,##0.##########")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNumberButtons()
        setupOperatorButtons()
        setupFunctionButtons()

        updateDisplay()
    }

    private fun setupNumberButtons() {
        val map = mapOf(
            binding.btn0 to "0", binding.btn1 to "1", binding.btn2 to "2",
            binding.btn3 to "3", binding.btn4 to "4", binding.btn5 to "5",
            binding.btn6 to "6", binding.btn7 to "7", binding.btn8 to "8",
            binding.btn9 to "9"
        )
        for ((button, digit) in map) {
            button.setOnClickListener { onDigit(digit) }
        }
        binding.btnDot.setOnClickListener { onDot() }
    }

    private fun setupOperatorButtons() {
        binding.btnPlus.setOnClickListener { onOperator("+") }
        binding.btnMinus.setOnClickListener { onOperator("−") }
        binding.btnMultiply.setOnClickListener { onOperator("×") }
        binding.btnDivide.setOnClickListener { onOperator("÷") }
        binding.btnEquals.setOnClickListener { onEquals() }
    }

    private fun setupFunctionButtons() {
        binding.btnClear.setOnClickListener { onClear() }
        binding.btnDelete.setOnClickListener { onDelete() }
        binding.btnPercent.setOnClickListener { onPercent() }
        binding.btnSign.setOnClickListener { onToggleSign() }
    }

    private fun onDigit(digit: String) {
        if (justCalculated) {
            // Начинаем новый ввод после результата
            currentNumber = "0"
            storedValue = null
            pendingOperator = null
            expressionText = ""
            justCalculated = false
        }
        currentNumber = if (currentNumber == "0") digit else currentNumber + digit
        updateDisplay()
    }

    private fun onDot() {
        if (justCalculated) {
            currentNumber = "0"
            storedValue = null
            pendingOperator = null
            expressionText = ""
            justCalculated = false
        }
        if (!currentNumber.contains(".")) {
            currentNumber += "."
            updateDisplay()
        }
    }

    private fun onOperator(op: String) {
        justCalculated = false
        val current = currentNumber.toDoubleOrNull() ?: 0.0

        if (storedValue != null && pendingOperator != null) {
            // Есть незавершённая операция — вычисляем цепочку последовательно
            storedValue = calculate(storedValue!!, current, pendingOperator!!)
        } else {
            storedValue = current
        }

        pendingOperator = op
        expressionText = "${formatNumber(storedValue!!)} $op"
        currentNumber = "0"
        updateDisplay(showStoredAsResult = true)
    }

    private fun onEquals() {
        val current = currentNumber.toDoubleOrNull() ?: 0.0
        if (storedValue != null && pendingOperator != null) {
            val result = calculate(storedValue!!, current, pendingOperator!!)
            expressionText = "${formatNumber(storedValue!!)} $pendingOperator ${formatNumber(current)} ="
            currentNumber = formatNumber(result)
            storedValue = null
            pendingOperator = null
            justCalculated = true
            updateDisplay()
        }
    }

    private fun onClear() {
        currentNumber = "0"
        storedValue = null
        pendingOperator = null
        expressionText = ""
        justCalculated = false
        updateDisplay()
    }

    private fun onDelete() {
        if (justCalculated) {
            onClear()
            return
        }
        currentNumber = if (currentNumber.length > 1) {
            currentNumber.dropLast(1)
        } else {
            "0"
        }
        updateDisplay()
    }

    private fun onPercent() {
        val current = currentNumber.toDoubleOrNull() ?: 0.0
        val result = if (storedValue != null) {
            // например 200 + 10% -> 10% от 200
            storedValue!! * (current / 100.0)
        } else {
            current / 100.0
        }
        currentNumber = formatNumber(result)
        updateDisplay()
    }

    private fun onToggleSign() {
        val current = currentNumber.toDoubleOrNull() ?: 0.0
        currentNumber = formatNumber(current * -1)
        updateDisplay()
    }

    private fun calculate(a: Double, b: Double, op: String): Double {
        return when (op) {
            "+" -> a + b
            "−" -> a - b
            "×" -> a * b
            "÷" -> if (b != 0.0) a / b else Double.NaN
            else -> b
        }
    }

    private fun formatNumber(value: Double): String {
        if (value.isNaN()) return "Ошибка"
        return if (value == value.toLong().toDouble()) {
            value.toLong().toString()
        } else {
            String.format(Locale.US, "%.10f", value)
                .trimEnd('0')
                .trimEnd('.')
        }
    }

    private fun updateDisplay(showStoredAsResult: Boolean = false) {
        binding.tvExpression.text = expressionText
        binding.tvResult.text = if (showStoredAsResult) {
            formatNumber(storedValue ?: 0.0)
        } else {
            currentNumber
        }
    }
}
