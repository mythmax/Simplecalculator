# Простой Калькулятор (Android)

Лёгкое нативное приложение-калькулятор на Kotlin. minSdk 29 (Android 10+),
без интернета, без рекламы.

## Шаг 1. Создайте репозиторий и загрузите архив

1. github.com → войдите/зарегистрируйтесь → `New repository` → любое
   имя (например `calculator-app`) → `Public` → создать (без
   README/gitignore).
2. На странице репозитория: `Add file` → `Upload files` → выберите
   **сам файл `calculator-project.zip`** (не распаковывая — это один
   файл, диалог выбора файлов такое принимает без проблем) → `Commit
   changes`.

## Шаг 2. Добавьте файл автосборки (создаётся прямо в браузере)

1. `Add file` → `Create new file`.
2. В поле имени файла введите ровно такой путь (со слэшами) —
   GitHub сам создаст нужные вложенные папки:
   ```
   .github/workflows/build-apk.yml
   ```
3. Вставьте в текстовое поле содержимое ниже целиком и нажмите
   `Commit changes`:

   ```yaml
   name: Build Debug APK

   on:
     push:
     workflow_dispatch:

   jobs:
     build:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v4

         - name: Unzip project sources (if uploaded as zip)
           run: |
             if [ -f calculator-project.zip ]; then
               unzip -o calculator-project.zip -d .
             fi

         - name: Set up JDK 17
           uses: actions/setup-java@v4
           with:
             distribution: 'temurin'
             java-version: '17'

         - name: Generate Gradle wrapper
           run: gradle wrapper --gradle-version 8.7

         - name: Build debug APK
           run: ./gradlew assembleDebug --no-daemon --stacktrace

         - name: Upload APK as build artifact
           uses: actions/upload-artifact@v4
           with:
             name: SimpleCalculator-debug-apk
             path: app/build/outputs/apk/debug/app-debug.apk
   ```

## Шаг 3. Скачайте готовый APK

1. Вкладка `Actions` в репозитории — сборка `Build Debug APK` запустится
   сама (2–4 минуты).
2. Откройте зелёный запуск → внизу раздел `Artifacts` → скачайте
   `SimpleCalculator-debug-apk.zip`.
3. Внутри — `app-debug.apk`. Перекиньте на телефон и установите
   (разрешив "Установку из неизвестных источников").

## Альтернатива без браузерных плясок: GitHub Desktop

Если не хочется возиться с ручным созданием файла с путём:
1. Установите GitHub Desktop (desktop.github.com) — лёгкое официальное
   приложение, не Android Studio.
2. Распакуйте `calculator-project.zip` в папку на диске.
3. В GitHub Desktop: `Add Local Repository` → укажите эту папку →
   `Publish repository`.
4. GitHub Desktop сам загрузит структуру папок как есть (в отличие от
   загрузки через сайт, тут ограничения на папки нет).
5. Всё равно нужно проделать Шаг 2 выше (создать файл workflow через
   сайт) — сама программа для этого не нужна, просто на сайте
   репозитория `Add file → Create new file`.
6. Дальше — Шаг 3.

## Локальная сборка (если есть Android Studio)

1. Распакуйте `calculator-project.zip`.
2. Android Studio → `Open` → выберите эту папку.
3. Дождитесь синхронизации Gradle.
4. `Build` → `Build APK(s)`.
5. Файл: `app/build/outputs/apk/debug/app-debug.apk`.

## Что внутри проекта

```
build.gradle.kts / settings.gradle.kts / gradle.properties  — сборка
app/build.gradle.kts                                        — minSdk 29, зависимости
app/src/main/java/com/simplecalc/app/MainActivity.kt         — логика калькулятора
app/src/main/res/                                            — layout, цвета, стили, иконка
```

Только стандартные AndroidX/Material — без лишнего веса.
